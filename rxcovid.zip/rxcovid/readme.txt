Patches of 64x64 pixels of chest X-rays

class-0: Normal
class-1: Pneumonia
class-2: COVID

Training Subset: 1680 images per class
Testing Subset:   420 images per class

Disclaimer: 
The primary purpose of content marked as "educational" is to facilitate learning and teaching, whether in a formal or informal setting.